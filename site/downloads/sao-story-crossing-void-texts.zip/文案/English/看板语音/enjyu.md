# enjyu

按剧情片段顺序和时间轴排列。标有“时刻未确认”的场景文字按片段收录；原作语录按所属角色归档。


## Aen_s00_1100 / Aen_s00_1100

**Enju Aihara：** I'm Enju Aihara,

<!-- text_id=2850210178 key=Aen_s00_1100_1 time=0.0 -->

**Enju Aihara：** the bunny Initiator.

<!-- text_id=418389089 key=Aen_s00_1100_2 time=2.7 -->


## Aen_s00_1130 / Aen_s00_1130

**Enju Aihara：** You can trust me with this!

<!-- text_id=3492861967 key=Aen_s00_1130 time=0.0 -->


## Aen00_2100 / Aen00_2100

**Enju Aihara：** What a perfect mate!

<!-- text_id=1940881169 key=Aen00_2100 time=0.0 -->
