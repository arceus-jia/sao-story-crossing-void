# role_004 Rentarou Satomi

按剧情片段顺序和时间轴排列。标有“时刻未确认”的场景文字按片段收录；原作语录按所属角色归档。


## book_19_chapter_1_page_156 / 401

Because if students are screened solely by their grades, famous universities will become nests of geeks.

<!-- text_id=4125028804 key=AnaContent_401 time= -->


## book_19_chapter_1_page_194 / 402

I've made up my mind! I will hold a pile of grenades when I die. I don't want any part of me left.

<!-- text_id=2830557479 key=AnaContent_402 time= -->


## book_19_chapter_1_page_199 / 403

The ultimate goal of the Civil Security Corporation is to eliminate the nine remaining Stage V Gastreas. No, maybe it should be called the sorrowful wish of mankind.

<!-- text_id=398736390 key=AnaContent_403 time= -->


## book_19_chapter_1_page_221 / 404

The most terrible thing about killing is that you will get used to it. When you kill someone and find yourself unpunished, you will slowly forget the sense of guilt.

<!-- text_id=1124532833 key=AnaContent_404 time= -->


## book_19_chapter_1_page_241 / 405

Please allow me to introduce myself,... I am Rentarou Satomi, a former Mechanical Soldier of the "New Human Creation Plan" implemented by No. 787 Mechanized Special Unit of the Eastern Army of the Ground Self-Defense Force.

<!-- text_id=2987679040 key=AnaContent_405 time= -->


## book_19_chapter_2_page_217 / 406

... I've seen hell. Ten years ago when humans were swallowed, torn, and fragmented by Gastreas, I was standing on a hill staring at the sky which was burning 360°. That is the most intimidating trauma I've ever had. I never wanted to recall or think about it. But I failed. Even if I had the privilege to hold Ms. Kisara and Enju in my arms, I will still recall the excruciatingly painful hell.

<!-- text_id=1693207715 key=AnaContent_406 time= -->


## book_19_chapter_3_page_111 / 407

Whether it is Ms. Kisara, Enju or me, we don't need you to take care of us! You are just a little kid, and don't think too much for us.

<!-- text_id=3556353922 key=AnaContent_407 time= -->


## book_19_chapter_3_page_118 / 408

...I want to change the world for Enju. To do that, I will have to knock down all the Stage V Gastreas!

<!-- text_id=241614829 key=AnaContent_408 time= -->
