# role_016 Tomoka Minato

按剧情片段顺序和时间轴排列。标有“时刻未确认”的场景文字按片段收录；原作语录按所属角色归档。


## BoardSpeech / 59

**Tomoka Minato：** We won!

<!-- text_id=171882983 key=board_Tmk00_2101 time= -->
