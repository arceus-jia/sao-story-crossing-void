# role_113 Accelerator

按剧情片段顺序和时间轴排列。标有“时刻未确认”的场景文字按片段收录；原作语录按所属角色归档。


## BoardSpeech / 98

**Accelerator：** Ah? What are you looking at?

<!-- text_id=1112346684 key=Acr_s00_1100 time= -->
